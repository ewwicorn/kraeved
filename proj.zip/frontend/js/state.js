/* ════ STATE ════ */

const S = {
  loggedIn: false,
  user: null,
  obDone: false,
  wishlist: [],
  interactions: 0,
  _savedOnce: {},
  authMode: 'login',
  feedCat: 'all',
  feedLoaded: 15,
  transport: 'car',
  group: 'solo',
  budget: 20000,
  acts: ['gastro', 'eco'],
  curPost: null,
  pmIdx: 0,
  vidInterval: null,
  vidSlide: 0,
  vidImgs: [],
  swapIdx: 0,
  tourPts: [],

  _apiPosts: [],
  _apiPostsLoaded: false,
  _apiLocMap: {},
};

/* ── Персистентность ── */
(function restoreState() {
  try {
    const sv = JSON.parse(localStorage.getItem('kv_s') || '{}');
    ['loggedIn','user','obDone','wishlist','interactions','_savedOnce'].forEach(k => {
      if (sv[k] !== undefined) S[k] = sv[k];
    });
  } catch (e) {}
})();

function saveS() {
  try {
    localStorage.setItem('kv_s', JSON.stringify({
      loggedIn:     S.loggedIn,
      user:         S.user,
      obDone:       S.obDone,
      wishlist:     S.wishlist,
      interactions: S.interactions,
      _savedOnce:   S._savedOnce,
    }));
  } catch (e) {}
}

function catFromTags(tags) {
  const map = {
    Вино:'wine', Гастро:'gastro', Ферма:'gastro', Природа:'nature',
    Море:'nature', Горы:'active', Трекинг:'active', Релакс:'wellness',
    Культура:'culture', Закат:'nature', Спа:'wellness', Термы:'wellness',
  };
  for (const t of tags) { if (map[t]) return map[t]; }
  return 'nature';
}

/* Теперь возвращает только API-посты — заглушек больше нет */
function getAllPosts() {
  return [...S._apiPosts];
}

async function loadApiPosts(force) {
  if (S._apiPostsLoaded && !force) return;
  try {
    try {
      const locsRes = await apiLocations({ page_size: 100 });
      const apiLocs = locsRes.items || locsRes || [];
      apiLocs.forEach(loc => { S._apiLocMap[loc.slug] = loc.id; });
    } catch (_) {}

    const res = await apiFeed(1, 50);
    const posts = (res.items || []).map(mapApiPost);
    await resolvePostPhotos(posts);
    S._apiPosts = posts;
    S._apiPostsLoaded = true;
  } catch (e) {
    S._apiPosts = [];
    S._apiPostsLoaded = true;
  }
}
